/* Rubik's Cube Object */

class RubikCube extends GraphicEntity{

    constructor(x, y, z){
        super(x, y, z);

        this.bumpMap = new THREE.TextureLoader().load("bumpmapRubik.png");

        this.material = [];
        this.material[0] = new THREE.MeshPhongMaterial({color: 0xffffff,
                                                        map: this.bumpMap,
                                                        bumpMap: this.bumpMap,
                                                        wireframe: false
                                                    });
        this.material[1] = new THREE.MeshBasicMaterial({color: 0xffffff,
                                                        map: this.bumpMap,
                                                        bumpMap: this.bumpMap, 
                                                        wireframe: false
                                                    });
        this.addCube(0, 0, 0);
    }

    addCube(x, y, z){
        this.geometry = new THREE.BoxGeometry(5, 5, 5);
        var mesh = new THREE.Mesh(this.geometry, this.material[0]);
        mesh.position.set(x, y, z);
        this.add(mesh);
    }
}