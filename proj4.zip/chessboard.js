/* Chessboard Object */

class Chessboard extends GraphicEntity{
    
    constructor(x, y, z){
        super(x, y, z);

        this.map = new THREE.TextureLoader().load("Tabuleiro.png");

        this.material = [];
        this.material[0] = new THREE.MeshPhongMaterial({color: 0xffffff,
                                                        map: this.map,
                                                        shininess: 25,
                                                        roughness: 1,
                                                        wireframe: false
                                                    });
        this.material[1] = new THREE.MeshBasicMaterial({color: 0xffffff,
                                                        map: this.map, 
                                                        wireframe: false
                                                    });
        this.addField(0, 0, 0);
    }

    addField(x, y, z){
        this.geometry = new THREE.BoxGeometry(100, 2, 100);
        //this.geometry.normalsNeedUpdate = true;

        this.geometry.faceVertexUvs[0] = [];
        for (var i = 0; i < this.geometry.faces.length; i++) {
            this.geometry.faceVertexUvs[0].push([
                new THREE.Vector2(0, 0),
                new THREE.Vector2(0, 0),
                new THREE.Vector2(0, 0),
            ]);
        }

        this.geometry.faceVertexUvs[0][4][0].set(0, 1);
        this.geometry.faceVertexUvs[0][4][1].set(0, 0);
        this.geometry.faceVertexUvs[0][4][2].set(1, 1);
        this.geometry.faceVertexUvs[0][5][0].set(0, 0);
        this.geometry.faceVertexUvs[0][5][1].set(1, 0);
        this.geometry.faceVertexUvs[0][5][2].set(1, 1);

        this.geometry.computeFaceNormals();

        var mesh = new THREE.Mesh(this.geometry, this.material[0]);
        mesh.position.set(x, y, z);
        this.add(mesh);
    }

    createChessBoard() {

        let geo = new THREE.BoxGeometry(200, 5, 200);

        geo.normalsNeedUpdate = true;
        let mat = new THREE.MeshPhongMaterial({color: 0x303030});

        let texture = new THREE.TextureLoader().load("textures/CG1.jpg");
        geo.faceVertexUvs[0] = [];
        for (let i = 0; i < geo.faces.length; i++) {
            geo.faceVertexUvs[0].push([
                new THREE.Vector2(0, 0),
                new THREE.Vector2(0, 0),
                new THREE.Vector2(0, 0),
            ]);
        }
        // Map texture to upper face
        geo.faceVertexUvs[0][4][0].set(0, 1);
        geo.faceVertexUvs[0][4][1].set(0, 0);
        geo.faceVertexUvs[0][4][2].set(1, 1);
        geo.faceVertexUvs[0][5][0].set(0, 0);
        geo.faceVertexUvs[0][5][1].set(1, 0);
        geo.faceVertexUvs[0][5][2].set(1, 1);

        texture.minFilter = THREE.LinearFilter;
        mat.map = texture;

        mat.shininess = 30;
        mat.flatShading = THREE.SmoothShading;
        mat.needsUpdate = true;
        geo.computeFaceNormals();

        let obj = new THREE.Mesh(geo, mat);
        return obj;
    }
}